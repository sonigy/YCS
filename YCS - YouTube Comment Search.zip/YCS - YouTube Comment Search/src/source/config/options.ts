const options = {
    autoload: false,
    highlightText: true,
    cache: true,
    autoClear: 200
};


export {
    options
};